 
package herencia;

public class Persona 
{
    
}
