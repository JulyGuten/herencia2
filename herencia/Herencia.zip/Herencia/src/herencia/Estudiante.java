
package herencia;

public class Estudiante 
{
    
}
