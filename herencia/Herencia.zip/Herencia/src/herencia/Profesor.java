
package herencia;

public class Profesor 
{
    
}
